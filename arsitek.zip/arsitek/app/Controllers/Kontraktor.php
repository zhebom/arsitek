<?php

namespace App\Controllers;

class Kontraktor extends BaseController
{
    public function index()
    {
  
         echo view('pages/kontraktor');
    }
}
