<?= $this->extend('template/layout'); ?>

<?= $this->section('content'); ?>



  <div class="section-putih p-3">
    <div class="container">
      <h5 class="mb-2">Data Kontraktor</h5>
      <div class="container text-center">
        <div class="row justify-content-center">
          <div class="col p-3">
            <div class="card-content">
              <div class="card">
                <img src="./heroes/engineer.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">CV. Harapan Bunda</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">Go somewhere</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col p-3">
            <div class="card-content">
              <div class="card">
                <img src="./heroes/engineer.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">CV. Harapan Bunda</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">Go somewhere</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col p-3">
            <div class="card-content">
              <div class="card">
                <img src="./heroes/engineer.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">CV. Harapan Bunda</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">Go somewhere</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col p-3">
            <div class="card-content">
              <div class="card">
                <img src="./heroes/engineer.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">CV. Harapan Bunda</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">Go somewhere</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col p-3">
            <div class="card-content">

              <div class="card">
                <img src="./heroes/engineer.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">CV. Harapan Bunda</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">Go somewhere</a>
                </div>
              </div>
            </div>
          </div>
          <div class="col p-3">
            <div class="card-content">

              <div class="card">
                <img src="./heroes/engineer.png" class="card-img-top" alt="...">
                <div class="card-body">
                  <h5 class="card-title">CV. Harapan Bunda</h5>
                  <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                  <a href="#" class="btn btn-warning">Go somewhere</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

 

    </div>

  </div>

  
  
  <?= $this->endSection(); ?>